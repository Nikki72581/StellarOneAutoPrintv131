<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormDetail.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="S1990020.aspx.cs" Inherits="Page_S1990020" Title="StellarOne PrintNode Job Log" %>
<%@ MasterType VirtualPath="~/MasterPages/FormDetail.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="StellarOneAutoPrint.SOStellarPrintJobLogMaint"
        PrimaryView="Log">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="Save" CommitChanges="True" />
			<px:PXDSCallbackCommand Name="ReprintOK" CommitChanges="True" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXFormView ID="formListFilter" runat="server" DataSourceID="ds" DataMember="ListFilter" Width="100%" SkinID="Transparent" CaptionVisible="False">
		<Template>
			<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="SM" />
			<px:PXDateTimeEdit ID="edtDateFrom" runat="server" DataField="DateFrom" CommitChanges="True" />
		</Template>
	</px:PXFormView>
	<px:PXGrid ID="grid" runat="server" DataSourceID="ds" Width="100%" Height="500px" SkinID="Inquire"
		Caption="Print Job Log" CaptionVisible="True" AdjustPageSize="Auto" AllowPaging="True">
		<AutoSize Enabled="True" Container="Window" MinHeight="400" />
		<Mode AllowAddNew="False" AllowDelete="False" />
		<Levels>
			<px:PXGridLevel DataMember="Log">
				<Columns>
					<px:PXGridColumn DataField="LogID" Width="70px" />
					<px:PXGridColumn DataField="CreatedDateTime" Width="140px" />
					<px:PXGridColumn DataField="ShipmentNbr" Width="110px" />
					<px:PXGridColumn DataField="PackageLineNbr" Width="70px" />
					<px:PXGridColumn DataField="JobType" Width="130px" RenderEditorText="True" />
					<px:PXGridColumn DataField="Description" Width="200px" />
					<px:PXGridColumn DataField="PrinterName" Width="150px" />
					<px:PXGridColumn DataField="ComputerName" Width="150px" />
					<px:PXGridColumn DataField="Status" Width="80px" RenderEditorText="True" />
					<px:PXGridColumn DataField="ErrorMessage" Width="250px" />
					<px:PXGridColumn DataField="PrintNodeJobID" Width="110px" />
					<px:PXGridColumn DataField="SourceLogID" Width="90px" />
					<px:PXGridColumn DataField="CreatedByID" Width="150px" />
				</Columns>
			</px:PXGridLevel>
		</Levels>
		<ActionBar>
			<CustomItems>
				<px:PXToolBarButton Text="Reprint" PopupPanel="pnlReprint" />
			</CustomItems>
		</ActionBar>
	</px:PXGrid>

	<px:PXSmartPanel ID="pnlReprint" runat="server" Caption="Reprint" Key="Filter"
		AutoRepaint="True" CaptionVisible="True" LoadOnDemand="True" Width="380px" Height="160px">
		<px:PXFormView ID="formReprint" runat="server" DataSourceID="ds" DataMember="Filter" Width="100%">
			<Template>
				<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="M" />
				<px:PXSelector ID="edReprintPrinterID" runat="server" DataField="PrinterID" />
			</Template>
		</px:PXFormView>
		<px:PXPanel runat="server" ID="pnlReprintButtons" SkinID="Buttons">
			<px:PXButton ID="btnReprintOK" runat="server" Text="OK" CommandName="ReprintOK" CommandSourceID="ds" />
			<px:PXButton ID="btnReprintCancel" runat="server" Text="Cancel" DialogResult="Cancel" />
		</px:PXPanel>
	</px:PXSmartPanel>
</asp:Content>
