
import { createCollection, createSingle, graphInfo, viewInfo, PXView, PXScreen, PXFieldState, gridConfig, PXFieldOptions, PXActionState, GridPreset } from "client-controls";

@graphInfo({
	graphType: "StellarOneAutoPrint.SOStellarPrintNodeSetupMaint",
	primaryView: "Setup",
})
export class S1990010 extends PXScreen {
	TestPrintNodeConnection: PXActionState;
	RefreshPrinterName: PXActionState;

	Setup = createSingle(Setup);

	@viewInfo({ containerName: "User Printer Mappings" })
	PrintNodeUserMappings = createCollection(PrintNodeUserMappings);

	@viewInfo({ containerName: "Synced Printers" })
	PrintNodePrinters = createCollection(PrintNodePrinters);
}

export class Setup extends PXView {
	EnhancedPrintingEnabled: PXFieldState;
	GiftNoteReportID: PXFieldState;
	ConfirmReportID: PXFieldState;

	PrintNodeApiKey: PXFieldState;

	GiftNotePrinterID: PXFieldState;
	LabelPrinterID: PXFieldState;
	ConfirmPrinterID: PXFieldState;
}

@gridConfig({
	preset: GridPreset.Details,
	adjustPageSize: true,
})
export class PrintNodeUserMappings extends PXView {
	UserID: PXFieldState;
	PrintJobType: PXFieldState;
	PrinterID: PXFieldState<PXFieldOptions.CommitChanges>;
	PrinterName: PXFieldState;
	ComputerName: PXFieldState;
	IsActive: PXFieldState;
}

@gridConfig({
	preset: GridPreset.Inquiry,
	adjustPageSize: true,
})
export class PrintNodePrinters extends PXView {
	PrinterID: PXFieldState;
	PrinterName: PXFieldState;
	ComputerName: PXFieldState;
	State: PXFieldState;
	IsActive: PXFieldState;
	LastSyncedDateTime: PXFieldState;
}
