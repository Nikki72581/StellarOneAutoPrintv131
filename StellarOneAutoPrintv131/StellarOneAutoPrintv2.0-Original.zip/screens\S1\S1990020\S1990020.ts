
import { createCollection, createSingle, graphInfo, viewInfo, PXView, PXScreen, PXFieldState, gridConfig, PXActionState, GridPreset } from "client-controls";

@graphInfo({
	graphType: "StellarOneAutoPrint.SOStellarPrintJobLogMaint",
	primaryView: "Log",
})
export class S1990020 extends PXScreen {
	ReprintOK: PXActionState;

	@viewInfo({ containerName: "Print Job Log" })
	Log = createCollection(Log);

	Filter = createSingle(Filter);
}

@gridConfig({
	preset: GridPreset.Inquiry,
	adjustPageSize: true,
})
export class Log extends PXView {
	LogID: PXFieldState;
	CreatedDateTime: PXFieldState;
	ShipmentNbr: PXFieldState;
	PackageLineNbr: PXFieldState;
	JobType: PXFieldState;
	Description: PXFieldState;
	PrinterName: PXFieldState;
	ComputerName: PXFieldState;
	Status: PXFieldState;
	ErrorMessage: PXFieldState;
	PrintNodeJobID: PXFieldState;
	SourceLogID: PXFieldState;
	CreatedByID: PXFieldState;
}

export class Filter extends PXView {
	PrinterID: PXFieldState;
}
