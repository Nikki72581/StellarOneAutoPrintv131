<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormTab.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="S1990010.aspx.cs" Inherits="Page_S1990010" Title="StellarOne PrintNode Setup" %>
<%@ MasterType VirtualPath="~/MasterPages/FormTab.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="StellarOneAutoPrint.SOStellarPrintNodeSetupMaint"
        PrimaryView="Setup">
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="Save" CommitChanges="True" />
		</CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXFormView ID="form" runat="server" DataSourceID="ds" DataMember="Setup" Width="100%" DefaultControlID="edEnhancedPrintingEnabled">
		<Template>
			<px:PXLayoutRule ID="PXLayoutRule1" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
			<px:PXCheckBox ID="edEnhancedPrintingEnabled" runat="server" DataField="EnhancedPrintingEnabled" />
			<px:PXSelector ID="edGiftNoteReportID" runat="server" DataField="GiftNoteReportID" />
			<px:PXSelector ID="edConfirmReportID" runat="server" DataField="ConfirmReportID" />

			<px:PXLayoutRule ID="PXLayoutRule2" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
			<px:PXTextEdit ID="edPrintNodeApiKey" runat="server" DataField="PrintNodeApiKey" TextMode="Password" />
			<px:PXButton ID="btnTestConnection" runat="server" Text="Test PrintNode Connection"
				CommandSourceID="ds" CommandName="TestPrintNodeConnection" />

			<px:PXLayoutRule ID="PXLayoutRule3" runat="server" StartColumn="True" LabelsWidth="SM" ControlSize="M" />
			<px:PXSelector ID="edGiftNotePrinterID" runat="server" DataField="GiftNotePrinterID" />
			<px:PXSelector ID="edLabelPrinterID" runat="server" DataField="LabelPrinterID" />
			<px:PXSelector ID="edConfirmPrinterID" runat="server" DataField="ConfirmPrinterID" />
		</Template>
	</px:PXFormView>
</asp:Content>
<asp:Content ID="cont3" ContentPlaceHolderID="phG" Runat="Server">
	<px:PXTab ID="tab" runat="server" Width="100%" Height="400px" DataSourceID="ds">
		<Items>
			<px:PXTabItem Text="User Printer Mappings">
				<Template>
					<px:PXGrid ID="gridMappings" runat="server" DataSourceID="ds" Width="100%" SkinID="Details"
						Caption="Per-User Printer Overrides" CaptionVisible="True" AdjustPageSize="Auto" AllowPaging="True">
						<AutoSize Enabled="True" />
						<Levels>
							<px:PXGridLevel DataMember="PrintNodeUserMappings">
								<RowTemplate>
									<px:PXLayoutRule runat="server" StartColumn="True" LabelsWidth="M" ControlSize="XM" />
									<px:PXSelector ID="edUserID" runat="server" DataField="UserID" />
									<px:PXDropDown ID="edPrintJobType" runat="server" DataField="PrintJobType" />
									<px:PXSelector ID="edPrinterID" runat="server" DataField="PrinterID" CommitChanges="True" />
									<px:PXTextEdit ID="edPrinterName" runat="server" DataField="PrinterName" />
									<px:PXTextEdit ID="edComputerName" runat="server" DataField="ComputerName" />
									<px:PXCheckBox ID="edIsActive" runat="server" DataField="IsActive" />
								</RowTemplate>
								<Columns>
									<px:PXGridColumn DataField="UserID" Width="150px" />
									<px:PXGridColumn DataField="PrintJobType" Width="150px" RenderEditorText="True" />
									<px:PXGridColumn DataField="PrinterID" Width="120px" AutoCallBack="True" />
									<px:PXGridColumn DataField="PrinterName" Width="200px" />
									<px:PXGridColumn DataField="ComputerName" Width="150px" />
									<px:PXGridColumn DataField="IsActive" Width="70px" TextAlign="Center" Type="CheckBox" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
						<ActionBar>
							<CustomItems>
								<px:PXToolBarButton Text="Refresh Printer Name" CommandName="RefreshPrinterName" CommandSourceID="ds" />
							</CustomItems>
						</ActionBar>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
			<px:PXTabItem Text="Synced Printers">
				<Template>
					<px:PXGrid ID="gridPrinters" runat="server" DataSourceID="ds" Width="100%" SkinID="Details"
						Caption="Last-Synced PrintNode Printers" CaptionVisible="True" AdjustPageSize="Auto" AllowPaging="True">
						<AutoSize Enabled="True" />
						<Mode AllowAddNew="False" AllowDelete="False" />
						<Levels>
							<px:PXGridLevel DataMember="PrintNodePrinters">
								<Columns>
									<px:PXGridColumn DataField="PrinterID" Width="120px" />
									<px:PXGridColumn DataField="PrinterName" Width="200px" />
									<px:PXGridColumn DataField="ComputerName" Width="150px" />
									<px:PXGridColumn DataField="State" Width="100px" />
									<px:PXGridColumn DataField="IsActive" Width="70px" TextAlign="Center" Type="CheckBox" />
									<px:PXGridColumn DataField="LastSyncedDateTime" Width="150px" />
								</Columns>
							</px:PXGridLevel>
						</Levels>
					</px:PXGrid>
				</Template>
			</px:PXTabItem>
		</Items>
		<AutoSize Container="Window" Enabled="True" MinHeight="400" />
	</px:PXTab>
</asp:Content>
